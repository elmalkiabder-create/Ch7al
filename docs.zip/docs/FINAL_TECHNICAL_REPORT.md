# Rapport Technique Final - Application "Hanout Price"

## 1. Introduction : De l'Idée à la Réalité

Le projet **Hanout Price** est né d'une vision simple mais puissante : créer une application mobile et web communautaire pour le marché marocain, permettant aux utilisateurs de trouver, partager et comparer les prix des produits de consommation courante. L'objectif était de construire une base de données transparente et collaborative pour aider les consommateurs à réaliser des économies et à identifier les meilleures offres autour d'eux.

Ce document retrace le parcours de développement, de la planification initiale à l'application fonctionnelle, en passant par les défis techniques rencontrés et les solutions implémentées.

---

## 2. Architecture Technique Finale

L'application a été bâtie sur une stack moderne et robuste, choisie pour sa rapidité de développement, sa scalabilité et son intégration native avec l'écosystème Google Cloud.

| Domaine | Technologie | Rôle et Justification |
| :--- | :--- | :--- |
| **Framework Web** | **Next.js (App Router)** | Utilisé pour sa structure performante (SSR/SSG), ses Server Actions et sa gestion optimisée des composants React. L'App Router a permis une organisation logique des routes et une séparation claire entre composants serveur et client. |
| **UI & Style** | **React, Shadcn/UI, TailwindCSS** | Une combinaison offrant une grande flexibilité de style via Tailwind, avec une bibliothèque de composants accessibles et esthétiques (Shadcn/UI) pour construire une interface utilisateur cohérente et moderne. |
| **Base de Données** | **Firebase Firestore** | Base de données NoSQL temps réel, choisie pour sa scalabilité, ses requêtes flexibles et sa synchronisation instantanée, idéale pour une application communautaire (mises à jour de prix, votes, commentaires). |
| **Authentification**| **Firebase Authentication**| Gestion sécurisée des utilisateurs avec des fournisseurs multiples (Email/Mot de passe, Google), parfaitement intégrée à l'écosystème Firebase. |
| **Stockage Fichiers**| **Firebase Storage** | Solution pour héberger de manière sécurisée et scalable les images de produits téléversées par les utilisateurs. |
| **IA (Backend)** | **Genkit (Google AI)** | Le cœur de la fonctionnalité de reconnaissance de produits. Un flux Genkit (`recognizeProductFlow`) analyse les images prises par les utilisateurs pour en extraire automatiquement le nom du produit et son prix, simplifiant drastiquement la saisie manuelle. |
| **Recherche** | **Algolia** | Intégrée pour offrir une expérience de recherche de produits instantanée et performante, synchronisée avec Firestore via des Cloud Functions. |
| **Fonctions Backend**| **Firebase Cloud Functions** | Utilisées pour des logiques serveur critiques : synchronisation des données avec Algolia, calcul des points et attribution des badges, et mise à jour des notes moyennes des magasins. |
| **Internationalisation**| **i18next** | Support multilingue (Français, Anglais, Arabe, Darija) avec détection automatique de la langue et gestion des layouts RTL (Right-to-Left). |

---

## 3. Problèmes Rencontrés et Solutions Apportées

Le développement a été marqué par plusieurs défis techniques typiques des applications web modernes. Leur résolution a permis de renforcer la robustesse de l'application.

### 3.1 Erreurs d'Hydratation React (🔴 Majeur)

*   **Problème** : L'erreur `Hydration failed because the server rendered HTML didn't match the client` apparaissait fréquemment, notamment à cause du composant de changement de langue (`LanguageSwitcher`) qui dépendait d'informations uniquement disponibles côté client (ex: `localStorage`).
*   **Solution** : La solution la plus efficace a été de s'assurer que les composants posant problème ne soient jamais rendus côté serveur. Nous avons utilisé `next/dynamic` avec l'option `ssr: false` pour charger dynamiquement ces composants uniquement sur le client. Cela a définitivement éliminé les divergences entre le rendu serveur et client.

### 3.2 Erreur `OverconstrainedError` de la Caméra (🟡 Moyen)

*   **Problème** : Sur les appareils sans caméra arrière (comme la plupart des ordinateurs portables), la tentative d'accéder à la caméra avec la contrainte `facingMode: { exact: "environment" }` échouait, bloquant la fonctionnalité de prise de photo.
*   **Solution** : Nous avons implémenté une logique de **fallback**. Le code tente d'abord d'accéder à la caméra arrière. En cas d'échec, il ré-essaie avec une contrainte plus simple (`video: true`), ce qui permet au navigateur de choisir n'importe quelle caméra disponible, assurant ainsi que la fonctionnalité reste accessible sur un plus grand nombre d'appareils.

### 3.3 Erreur `addDoc()` avec champ `undefined` (🔴 Majeur)

*   **Problème** : Lors de la soumission d'un prix sans code-barres, le champ `barcode` était envoyé à Firestore avec la valeur `undefined`, ce que Firestore interdit, provoquant une `FirebaseError`.
*   **Solution** : La logique de soumission a été modifiée pour construire l'objet de données de manière conditionnelle. En utilisant l'opérateur de décomposition (spread), le champ `barcode` n'est ajouté à l'objet que s'il a une valeur définie et non-vide. Dans le cas contraire, il est simplement omis, ce qui est parfaitement géré par Firestore.

### 3.4 Améliorations de l'Expérience Utilisateur (UX)

*   **Problème** : Le formulaire d'ajout de produit était initialement dense et pouvait paraître intimidant. Le processus de capture de photo manquait de feedback visuel.
*   **Solution** :
    1.  Le flux d'ajout a été **divisé en deux étapes** : une première étape centrée sur la capture (photo), puis une seconde pour la confirmation des détails pré-remplis par l'IA.
    2.  La modale de la caméra a été enrichie avec un **indicateur de chargement** et des **messages d'erreur clairs** en cas de problème de permission, rendant l'expérience plus fluide.

---

## 4. Vision et Évolutions Futures Possibles

L'application Hanout Price dispose d'une fondation solide qui ouvre la voie à de nombreuses améliorations et nouvelles fonctionnalités.

### Fonctionnalités à court terme

1.  **Notifications Push** :
    *   Alerter les utilisateurs lorsqu'un produit de leur liste de courses est disponible à un prix inférieur à un certain seuil.
    *   Notifier les utilisateurs lorsqu'ils débloquent un nouveau badge.

2.  **Amélioration du Profil Social** :
    *   Permettre aux utilisateurs de suivre d'autres contributeurs.
    *   Créer un "fil d'activité" personnalisé montrant les contributions des personnes suivies.

3.  **Scan de Reçus** :
    *   Développer un flux Genkit capable d'analyser une photo de ticket de caisse pour en extraire plusieurs produits et prix en une seule fois, accélérant massivement la contribution.

4.  **Listes de Courses Thématiques** :
    *   Permettre aux utilisateurs de créer et partager des listes de courses (ex: "Panier Ramadan", "Produits pour bébé"). L'application pourrait alors calculer le coût total du panier le moins cher dans un périmètre donné.

### Vision à long terme

*   **Partenariats avec les commerçants** : Créer un portail pour les propriétaires de "hanouts" leur permettant de mettre à jour leurs propres prix, de proposer des promotions exclusives aux utilisateurs de l'application, et d'analyser les tendances de consommation dans leur quartier.
*   **Analyse de données et tendances** : Fournir des statistiques anonymisées sur l'évolution des prix des produits de base au niveau local et national, devenant ainsi un baromètre de l'inflation pour le grand public.
*   **Expansion Géographique et Linguistique** : Déployer l'application dans d'autres pays du Maghreb et d'Afrique avec des adaptations culturelles et linguistiques.

Ce projet a démontré la puissance d'une approche itérative, où l'identification et la résolution de problèmes concrets ont permis de construire une application non seulement fonctionnelle, mais aussi agréable et intuitive à utiliser.
