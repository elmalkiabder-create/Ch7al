# Projet Hanout Price : Application Mobile Communautaire de Comparaison des Prix au Maroc

Votre choix d'utiliser **Capacitor** combiné avec **Firebase** représente une décision stratégique excellente pour le développement de l'application Hanout Price. Cette architecture hybride moderne offre un équilibre optimal entre rapidité de développement, performance native et évolutivité, tout en s'appuyant sur l'écosystème robuste de Firebase pour la gestion backend. Ce rapport présente une analyse approfondie et enrichie du plan projet, avec des insights techniques détaillés basés sur les meilleures pratiques actuelles de l'industrie.

## Architecture Technique et Choix Technologiques

L'architecture proposée repose sur trois piliers fondamentaux qui garantissent la viabilité technique et la scalabilité du projet.

### Capacitor comme Bridge Natif

Capacitor, développé par l'équipe Ionic, se positionne comme la solution de prédilection pour transformer une application web en application mobile native. Contrairement à ses prédécesseurs, Capacitor offre plusieurs avantages décisifs. Premièrement, il permet d'utiliser les standards web modernes (HTML5, CSS3, JavaScript ES6+) tout en accédant aux fonctionnalités natives des appareils via des plugins bien maintenus. Deuxièmement, Capacitor supporte nativement les Progressive Web Apps (PWA), ce qui signifie que votre application peut fonctionner aussi bien sur mobile que sur desktop avec un seul codebase.

L'intégration de Capacitor avec React et Ionic Framework crée un environnement de développement cohérent et productif. Ionic fournit une bibliothèque complète de composants UI pré-construits qui s'adaptent automatiquement à la plateforme (iOS ou Android), garantissant une expérience utilisateur native sans effort supplémentaire. Cette approche "adaptive styling" assure que les utilisateurs marocains bénéficient d'une interface familière quelle que soit leur plateforme.

### Écosystème Firebase comme Backend Complet

Firebase constitue l'épine dorsale backend de l'application, offrant une suite intégrée de services essentiels. **Firebase Authentication** gère l'authentification multi-méthodes (email/mot de passe, Google Sign-In, authentification par téléphone), particulièrement pertinent pour le contexte marocain où l'authentification par numéro de téléphone est largement adoptée. L'implémentation avec Capacitor utilise le plugin `@capacitor-firebase/authentication` qui fournit une interface unifiée entre les SDK natifs et web.

**Cloud Firestore** sert de base de données NoSQL temps réel, offrant des capacités de synchronisation instantanée et de requêtes complexes. Sa structure de collections et documents s'adapte parfaitement aux besoins de Hanout Price : collections pour les utilisateurs, produits, prix, hanouts, contributions et classements. Firestore offre également des capacités de géolocalisation via les GeoPoints, essentielles pour localiser les commerces à proximité.

**Firebase Storage** permet le stockage sécurisé des images de produits et reçus, avec compression automatique et URLs générées pour un accès rapide. **Cloud Functions** (optionnel mais recommandé) permet d'exécuter du code backend pour des tâches comme l'attribution automatique de badges, le calcul des classements ou l'envoi de notifications. Ces fonctions serverless s'exécutent en réponse à des événements Firebase (ajout de document, modification de données).

### Plugins Capacitor Essentiels

Le projet nécessite plusieurs plugins Capacitor critiques, chacun apportant des fonctionnalités natives spécifiques.

**Scanner de Code-Barres** : Deux options principales s'offrent à vous. Le plugin officiel `@capacitor/barcode-scanner` d'Ionic, récemment introduit comme plugin core supporté, offre une interface simple pour scanner divers types de codes-barres et QR codes. Alternativement, le plugin `@capacitor-mlkit/barcode-scanning` de Capawesome utilise ML Kit de Google, offrant des fonctionnalités avancées comme la détection simultanée de plusieurs codes-barres, la définition de zones de détection et le support de la lampe torche. Pour Hanout Price, le plugin ML Kit est recommandé car il offre une meilleure performance et plus de flexibilité.

**Géolocalisation** : Le plugin `@capacitor/geolocation` fournit un accès direct au GPS de l'appareil, permettant de récupérer les coordonnées actuelles avec précision (latitude, longitude, altitude). Ceci est essentiel pour associer les prix aux hanouts spécifiques et afficher les commerces à proximité sur une carte interactive. Pour une expérience optimale, l'intégration avec une bibliothèque de cartographie comme Leaflet ou Mapbox est recommandée.

**Firebase Plugins** : La collection `@capacitor-firebase` de Capawesome offre des plugins optimisés pour chaque service Firebase (Authentication, Firestore, Storage, Analytics). Ces plugins maintiennent la cohérence de version entre les SDK natifs et web, évitant les conflits de dépendances fréquents. Ils supportent également Capacitor 7, la version la plus récente.

## Support Multilingue et Localisation

Pour une application destinée au marché marocain, le support multilingue n'est pas une option mais une nécessité absolue. Le Maroc présente une situation linguistique unique avec trois langues principales : le français (langue administrative et commerciale), l'arabe classique (langue officielle) et le darija (arabe dialectal marocain largement parlé).

### Implémentation avec react-i18next

La bibliothèque `react-i18next` est la solution standard pour l'internationalisation dans les applications React. Son intégration suit un pattern éprouvé basé sur des fichiers de traduction JSON et un système de contexte React.

La configuration initiale implique la création d'un fichier `i18n.js` qui initialise i18next avec trois composants clés. **i18next-browser-languagedetector** détecte automatiquement la langue préférée de l'utilisateur basée sur les paramètres du navigateur ou du système d'exploitation. **i18next-http-backend** charge dynamiquement les fichiers de traduction depuis le dossier `/public/locales/`, permettant d'ajouter de nouvelles traductions sans recompiler l'application. **initReactI18next** intègre i18next avec React, rendant disponible le hook `useTranslation()` dans tous les composants.

La structure des fichiers de traduction suit une organisation par langue. Pour Hanout Price, vous auriez :
- `/public/locales/fr/translation.json` pour le français
- `/public/locales/ar/translation.json` pour l'arabe
- `/public/locales/darija/translation.json` pour le darija marocain

Chaque fichier contient des paires clé-valeur où la clé est un identifiant unique et la valeur est la traduction dans la langue cible. Par exemple, pour le bouton "Ajouter un prix", vous auriez `{"add_price": "Ajouter un prix"}` en français et `{"add_price": "إضافة سعر"}` en arabe.

### Considérations RTL (Right-to-Left)

L'arabe et le darija sont des langues RTL qui nécessitent une inversion complète de la direction du texte et de la mise en page. React-i18next facilite cela grâce à la méthode `i18n.dir()` qui retourne automatiquement "rtl" pour les langues arabes et "ltr" pour le français. En utilisant un `useEffect` hook, vous pouvez dynamiquement appliquer l'attribut `dir` au document :

```javascript
useEffect(() => {
  document.body.dir = i18n.dir();
}, [i18n, i18n.language]);
```

Cette approche garantit que toute l'interface s'adapte instantanément lors du changement de langue, inversant les menus, les icônes et les layouts.

## Système de Badges et Gamification

Le système de badges constitue l'un des éléments de différenciation majeurs de Hanout Price, transformant la contribution communautaire en une expérience engageante et gratifiante.

### Architecture du Système de Récompenses

L'architecture repose sur une approche événementielle utilisant Firebase Cloud Functions. Chaque action contributive (ajout de produit, signalement de prix, vérification) déclenche l'écriture d'un document dans la collection `contributions` de Firestore. Cette écriture active automatiquement une Cloud Function qui calcule les points, met à jour le profil utilisateur et vérifie l'éligibilité aux nouveaux badges.

Le système de points établit une hiérarchie claire des contributions. Ajouter un nouveau produit rapporte 10 points (action à forte valeur car elle enrichit la base de données), signaler un prix rapporte 5 points (contribution régulière encouragée), vérifier un prix existant rapporte 2 points (renforce la fiabilité des données), et ajouter un nouveau hanout rapporte 15 points (cartographie du territoire commercial). Cette échelle incite à diversifier les contributions plutôt que de se concentrer sur une seule action.

Les badges se divisent en deux catégories. Les **badges de progression** récompensent l'accumulation de points : Bronze (0-49 points), Silver (50-149 points), Gold (150-499 points), Platinum (500+ points). Les **badges spéciaux** célèbrent des accomplissements spécifiques : Premier Contributeur (premier à ajouter un produit), Photographe (10+ photos de produits uploadées), Explorateur (prix signalés dans 5+ villes différentes), Validateur (50+ vérifications effectuées), Maître des Séries (connexion quotidienne pendant 30 jours consécutifs).

### Implémentation Technique avec Cloud Functions

Une Cloud Function typique pour l'attribution de badges s'exécute en réponse à la création d'un document dans la collection `contributions` :

```javascript
exports.awardBadges = functions.firestore
  .document('contributions/{contributionId}')
  .onCreate(async (snap, context) => {
    const contribution = snap.data();
    const userId = contribution.userId;
    
    // Récupérer le profil utilisateur
    const userRef = admin.firestore().collection('users').doc(userId);
    const userDoc = await userRef.get();
    const userData = userDoc.data();
    
    // Calculer les nouveaux points
    const newPoints = userData.points + contribution.points;
    
    // Vérifier les critères de badges
    const newBadges = [];
    if (newPoints >= 500 && !userData.badges.includes('platinum')) {
      newBadges.push('platinum');
    }
    
    // Mettre à jour le profil
    await userRef.update({
      points: newPoints,
      badges: admin.firestore.FieldValue.arrayUnion(...newBadges)
    });
    
    // Envoyer notification si nouveau badge
    if (newBadges.length > 0) {
      // Logique de notification
    }
  });
```

Cette approche serverless garantit que la logique de récompense ne peut pas être contournée ou manipulée côté client, préservant l'intégrité du système.

### Classement et Compétition

Le système de classement utilise une collection `leaderboard` avec des documents organisés par période (hebdomadaire, mensuelle, annuelle, all-time). Une Cloud Function schedulée (déclenchée par Firebase Scheduler) recalcule les classements périodiquement, agrégeant les points et triant les utilisateurs. Cette approche pré-calculée permet d'afficher instantanément les classements sans requêtes coûteuses en temps réel.

## Sécurité et Rules Firebase

La sécurité de l'application repose entièrement sur les Firebase Security Rules, un système déclaratif qui définit qui peut lire, écrire, modifier ou supprimer quelle donnée.

### Structure des Security Rules

Les Security Rules de Firestore utilisent un langage spécifique basé sur des conditions booléennes. Pour Hanout Price, les règles suivent le principe du moindre privilège : autoriser uniquement ce qui est strictement nécessaire.

**Lecture publique, écriture authentifiée** : Les collections de produits, prix et hanouts sont lisibles par tous (y compris les utilisateurs non connectés) pour permettre la consultation des prix. Cependant, seuls les utilisateurs authentifiés peuvent ajouter des données :

```javascript
match /products/{productId} {
  allow read: if true;
  allow create: if request.auth != null;
  allow update, delete: if request.auth != null && 
                           resource.data.uploadedBy == request.auth.uid;
}
```

**Protection des profils utilisateurs** : Chaque utilisateur peut uniquement modifier son propre profil, mais les profils sont lisibles par tous pour afficher les classements :

```javascript
match /users/{userId} {
  allow read: if true;
  allow write: if request.auth != null && request.auth.uid == userId;
}
```

**Validation des données** : Les règles peuvent valider le format et le contenu des données avant l'écriture. Par exemple, pour les prix :

```javascript
match /prices/{priceId} {
  allow create: if request.auth != null &&
                   request.resource.data.price is number &&
                   request.resource.data.price > 0 &&
                   request.resource.data.currency == "MAD" &&
                   request.resource.data.reportedBy == request.auth.uid;
}
```

### App Check pour Protection Avancée

Firebase App Check ajoute une couche de sécurité supplémentaire en vérifiant que les requêtes proviennent bien de votre application authentique et non de bots ou d'applications clonées. Pour les applications mobiles, App Check utilise des attestations natives (Play Integrity API pour Android, App Attest pour iOS). Les Security Rules peuvent ensuite exiger une attestation App Check valide :

```javascript
match /prices/{priceId} {
  allow write: if request.auth != null && request.auth.token.app_check != null;
}
```

Cette protection est particulièrement importante pour Hanout Price, car elle empêche l'ajout automatisé massif de fausses données qui pourrait compromettre l'intégrité de la base de prix.

## Design et Expérience Utilisateur Marocaine

L'interface de Hanout Price doit refléter l'identité culturelle marocaine tout en respectant les standards modernes de UX/UI mobile.

### Palette de Couleurs et Identité Visuelle

La palette proposée s'inspire des couleurs traditionnelles des souks marocains. Le **vert dégradé** (du vert forêt au vert menthe) constitue la couleur primaire, évoquant la couleur symbolique du Maroc et rappelant les toits traditionnels en zellige vert. Le **jaune orangé** et l'**ocre terre cuite** servent de couleurs d'accentuation, reflétant les épices et les poteries des marchés traditionnels. Le **blanc** offre de la respiration visuelle et assure la lisibilité.

Les écrans affichés dans l'image de référence démontrent une application réussie de ces principes avec un fond vert profond pour l'écran d'ajout de prix, un fond vert pastel pour le classement et un fond orange chaleureux pour le profil. Cette variation de teintes maintient l'intérêt visuel tout en préservant la cohérence thématique.

### Composants Ionic Adaptés

Ionic Framework fournit des composants UI qui s'adaptent automatiquement à la plateforme tout en permettant une personnalisation poussée. Pour Hanout Price, les composants clés incluent `IonCard` pour afficher les produits et prix dans des cartes arrondies élégantes, `IonFab` (Floating Action Button) pour l'action principale d'ajout de prix accessible d'un seul geste, `IonModal` pour les formulaires d'ajout de produit ou de hanout avec animations fluides, `IonSearchbar` pour la recherche de produits avec suggestions en temps réel, et `IonSegment` pour basculer entre différentes vues (classement hebdomadaire/mensuel/annuel).

L'avantage d'Ionic réside dans sa capacité à créer des interfaces qui semblent natives tout en étant construites avec des technologies web. Les animations de transition, les patterns de navigation et même les haptic feedbacks sont gérés automatiquement.

### Navigation et Architecture de l'Information

La navigation suit le modèle "tab-based" typique des applications mobiles modernes, avec quatre onglets principaux visibles dans l'image de référence : Accueil (feed des derniers prix ajoutés, produits tendance), Classement (leaderboard avec filtres par période), Profil (statistiques personnelles, badges, historique de contributions), Recherche (barre de recherche puissante avec filtres par produit, quartier, prix).

Ce modèle de navigation parallèle permet aux utilisateurs marocains de basculer rapidement entre les fonctionnalités principales sans suivre un parcours linéaire, reflétant la nature exploratoire de la recherche de bonnes affaires dans les souks physiques.

## Processus de Développement et Déploiement

Le workflow de développement avec Capacitor et Firebase suit une méthodologie structurée garantissant qualité et efficacité.

### Phase 1 : Configuration Initiale (2-3 semaines)

La phase de préparation établit les fondations techniques et conceptuelles. Côté Firebase, créez un nouveau projet dans la Firebase Console, activez les services nécessaires (Authentication, Firestore, Storage), téléchargez les fichiers de configuration (`google-services.json` pour Android, `GoogleService-Info.plist` pour iOS) et définissez les Security Rules initiales en mode strict.

Côté développement, installez Node.js (version 18+), l'Ionic CLI (`npm install -g @ionic/cli`), et créez le projet React + Ionic (`ionic start hanout-price blank --type=react --capacitor`). Ajoutez ensuite les plugins Firebase (`npm install @capacitor-firebase/authentication @capacitor-firebase/firestore @capacitor-firebase/storage`), le scanner de code-barres (`npm install @capacitor-mlkit/barcode-scanning`), la géolocalisation (`npm install @capacitor/geolocation`) et react-i18next (`npm install react-i18next i18next i18next-browser-languagedetector i18next-http-backend`).

### Phase 2 : Développement Frontend (6-8 semaines)

Le développement suit une approche itérative par fonctionnalité. **Semaines 1-2** : Authentification avec formulaires de connexion/inscription utilisant Firebase Authentication, intégration de Google Sign-In pour simplifier l'accès, et gestion de l'état utilisateur avec React Context. **Semaines 3-4** : Scanner de code-barres avec intégration du plugin ML Kit, interface de scan avec overlay et instructions, et vérification du produit dans la base Firestore. **Semaines 5-6** : Ajout et recherche de prix avec formulaire de saisie de prix lié à la géolocalisation, upload de photos de reçus vers Firebase Storage, et recherche avec filtres multiples (produit, quartier, fourchette de prix). **Semaines 7-8** : Système de badges et classement avec calcul des contributions et affichage des badges, leaderboard dynamique et profil utilisateur complet.

### Phase 3 : Tests et Optimisation (2 semaines)

Les tests s'effectuent sur trois niveaux. **Tests navigateur** : Utilisez `ionic serve` pour le développement rapide et le hot-reload, vérifiez la responsivité sur différentes tailles d'écran et testez les fonctionnalités web (Firebase fonctionne entièrement dans le navigateur). **Tests émulateur** : Exécutez `ionic cap run android` pour tester sur l'émulateur Android Studio, vérifiez les fonctionnalités natives (scanner, GPS, notifications) et profilez les performances avec Chrome DevTools. **Tests appareil réel** : Déployez sur des appareils Android physiques via USB, testez dans des conditions réelles (réseau mobile, GPS précis, diverses versions d'Android) et recueillez les retours d'un groupe de beta-testeurs marocains.

### Phase 4 : Déploiement Play Store (1 semaine)

Le déploiement sur Google Play Store suit un processus standard mais nécessite une attention aux détails.

**Préparation de l'APK/AAB** : Générez le build de production avec `ionic build --prod`, synchronisez avec `npx cap sync android`, ouvrez le projet dans Android Studio avec `npx cap open android`, et configurez l'icône, le splash screen et le nom du package dans Android Studio.

**Signature de l'application** : Dans Android Studio, sélectionnez Build > Generate Signed Bundle/APK, choisissez Android App Bundle (AAB, format recommandé par Google), créez un nouveau keystore (fichier .jks) avec mot de passe sécurisé (conservez-le précieusement !), et générez l'AAB signé en mode Release. Le fichier généré se trouve dans `android/app/release/app-release.aab`.

**Soumission au Play Store** : Créez un compte Google Play Developer ($25 de frais uniques), créez une nouvelle application dans la Play Console, remplissez la fiche du Store (description, captures d'écran, catégorie), uploadez l'AAB signé, et soumettez pour révision (délai moyen : 1-3 jours). Assurez-vous de fournir des captures d'écran en français et en arabe pour maximiser l'attractivité auprès du public marocain.

## Avantages de l'Approche Capacitor + Firebase

Cette stack technologique offre des bénéfices substantiels particulièrement adaptés au contexte du projet Hanout Price.

**Réduction du Time-to-Market** : Capacitor permet de développer simultanément pour Android, iOS et web avec un seul codebase, réduisant drastiquement le temps de développement comparé à une approche native pure. Firebase élimine le besoin de développer, déployer et maintenir un backend custom, accélérant encore le processus.

**Coût de Développement Optimisé** : Une seule équipe de développeurs web (JavaScript/React) peut créer l'application complète, sans nécessiter des développeurs iOS Swift et Android Kotlin séparés. Firebase propose un tier gratuit généreux (Spark plan) suffisant pour le MVP et les premiers utilisateurs, et des tarifs "pay-as-you-grow" qui évolutionnent avec votre succès.

**Performance Proche du Natif** : Contrairement aux idées reçues sur les applications hybrides, Capacitor + React + Ionic offre des performances excellentes pour la majorité des cas d'usage. Les fonctionnalités critiques (scanner, GPS) utilisent des plugins natifs purs, garantissant des performances optimales. Le rendu UI via React et Ionic est hautement optimisé avec le Virtual DOM et les composants web standards.

**Scalabilité et Maintenance** : Firebase gère automatiquement la scalabilité backend, supportant de 0 à des millions d'utilisateurs sans intervention. L'architecture Capacitor facilite les mises à jour : modifiez le code React, rebuilder, et redéployer sans modifier les configurations natives dans la plupart des cas. La large communauté autour de React, Ionic et Firebase assure une abondance de ressources, tutoriels et support.

**Évolution vers iOS** : Si Hanout Price connaît le succès sur Android et que vous souhaitez cibler les utilisateurs iOS (segment premium au Maroc), le même codebase React peut être compilé pour iOS avec un effort minimal. Capacitor gère les spécificités de chaque plateforme, vous permettant de vous concentrer sur les ajustements UI mineurs et les tests spécifiques à la plateforme.

## Considérations Spécifiques au Marché Marocain

Le contexte marocain présente des particularités qui influencent les choix techniques et fonctionnels.

**Pénétration Smartphone et Connectivité** : Plus de 75% des Marocains utilisent un smartphone, avec une préférence marquée pour Android (environ 80% de part de marché). La connectivité 4G est généralisée dans les villes mais peut être instable dans certaines zones, nécessitant une gestion robuste du mode hors-ligne. Firestore offre nativement une capacité de persistance hors-ligne, permettant aux utilisateurs de consulter les derniers prix même sans connexion.

**Préférences de Paiement et Monétisation** : Si vous envisagez une future monétisation (publicités, abonnements premium), intégrez dès le départ des solutions de paiement locales. Au Maroc, les méthodes privilégiées incluent le paiement mobile (Cash Plus, Orange Money), les cartes bancaires locales (CMI), et de plus en plus PayPal et Stripe pour les paiements internationaux. Capacitor permet d'intégrer ces solutions via des plugins dédiés ou des WebViews sécurisées.

**Confiance et Vérification Communautaire** : La culture marocaine valorise fortement la confiance et la recommandation communautaire. Le système de vérification des prix par d'autres utilisateurs répond directement à cette attente culturelle. Encouragez la vérification croisée en récompensant les validations (points bonus) et affichez clairement le nombre de vérifications sur chaque prix. Affichez les profils des contributeurs actifs avec leurs badges pour créer une communauté identifiable et fiable.

**Localisation Géographique Précise** : Les adresses au Maroc peuvent être complexes et imprécises, particulièrement dans les quartiers traditionnels des médinas. Privilégiez la géolocalisation GPS combinée à des repères visuels (photos du hanout, description du quartier) plutôt que des adresses postales strictes. Implémentez une carte interactive permettant aux utilisateurs de pointer directement l'emplacement du commerce lors de l'ajout.

## Défis Potentiels et Mitigation

Tout projet ambitieux rencontre des obstacles. Anticiper ces défis permet de mieux les gérer.

**Qualité et Véracité des Données** : Le risque principal d'une plateforme communautaire est la pollution des données (prix erronés, produits inexistants, spamming). Mitigez cela en implémentant une modération légère avec un système de signalement permettant aux utilisateurs de reporter des prix suspects, un algorithme de détection d'anomalies (prix extrêmes, contributeur ajoutant massivement des données), et une validation manuelle pour les produits à forte valeur ajoutée. Firebase App Check et les Security Rules strictes empêchent les attaques automatisées.

**Engagement Utilisateur Initial** : Les plateformes de réseau requièrent une masse critique d'utilisateurs pour être utiles (effet de réseau). Stratégies de lancement : Commencez par un quartier pilote de Meknès (votre ville) avec une campagne locale ciblée, organisez des "events" de contribution communautaire avec récompenses (cartes cadeaux pour les meilleurs contributeurs du mois), et pré-peuplez la base avec quelques centaines de produits courants avant le lancement public.

**Performance avec Croissance des Données** : À mesure que la base de données grandit (dizaines de milliers de produits, centaines de milliers de prix), les requêtes peuvent ralentir. Optimisez en créant des indexes Firestore appropriés (sur `barcode`, `productId`, `location`, `timestamp`), implémentant la pagination pour les listes longues (20-50 items par page), et utilisant des requêtes limitées avec `.limit()` et curseurs pour le chargement progressif. Firestore peut gérer efficacement des millions de documents avec une indexation correcte.

**Coûts Firebase à l'Échelle** : Le plan gratuit de Firebase est limité (1 GB de stockage, 50k lectures/jour, 20k écritures/jour). À 10 000 utilisateurs actifs quotidiens, vous dépasserez probably ces limites. Le plan Blaze (pay-as-you-go) facture environ $0.06 par 100k lectures et $0.18 par 100k écritures. Surveillez l'usage via la console Firebase et optimisez les requêtes (évitez les lectures excessives, cachez les données localement, regroupez les écritures).

## Recommandations et Meilleures Pratiques

Pour maximiser les chances de succès de Hanout Price, adoptez ces pratiques éprouvées.

**Architecture Modulaire et Composants Réutilisables** : Structurez votre code React en composants atomiques réutilisables (ProductCard, PriceItem, BadgeDisplay, SearchBar). Cela facilite la maintenance, les tests et l'évolution future. Utilisez un state management centralisé (React Context ou Redux) pour gérer l'état global (utilisateur connecté, paramètres de langue, cache de données).

**Tests Automatisés Progressifs** : Même si le temps presse, implémentez des tests pour les fonctions critiques (calcul de points, validation de données, authentification). Jest pour les tests unitaires de logique JavaScript et Cypress pour les tests end-to-end de parcours utilisateur critiques (ajout de prix, scan de code-barres). Les tests préviennent les régressions lors des mises à jour futures.

**Analytics et Feedback Utilisateur** : Intégrez Firebase Analytics dès le départ pour tracker les événements clés (ouvertures de l'app, scans effectués, prix ajoutés, langues utilisées). Ces données informeront vos décisions de priorisation de fonctionnalités. Ajoutez un système de feedback in-app (simple formulaire ou intégration avec un outil comme Typeform) pour recueillir les suggestions utilisateurs.

**Optimisation Progressive** : Ne cherchez pas la perfection dès le MVP. Lancez avec les fonctionnalités core (scan, ajout prix, recherche, classement simple) et itérez rapidement basé sur les retours. Utilisez la méthodologie Lean Startup : Build-Measure-Learn. Chaque version doit tester une hypothèse clé (ex: "Les utilisateurs préfèrent-ils scanner ou chercher manuellement ?").

**Documentation et Connaissances** : Documentez votre code (commentaires clairs, README détaillé), les configurations Firebase (Security Rules, structure des collections) et le processus de déploiement. Ceci est crucial si vous envisagez d'agrandir l'équipe ou de transférer le projet à l'avenir. Utilisez des outils comme Notion ou Confluence pour centraliser la documentation technique et fonctionnelle.

## Conclusion et Vision à Long Terme

Le plan projet Hanout Price avec l'architecture Capacitor + Firebase représente une approche technologique moderne, pragmatique et évolutive parfaitement adaptée au contexte marocain. La combinaison de la rapidité de développement web avec la puissance des fonctionnalités natives via Capacitor, soutenue par l'infrastructure robuste et scalable de Firebase, crée les conditions optimales pour un lancement réussi et une croissance durable.

L'alignement avec les spécificités culturelles marocaines (multilingue français/arabe/darija, design inspiré des souks, focus sur la communauté et la vérification sociale) augmente significativement les chances d'adoption par les utilisateurs locaux. Le système de gamification avec badges et classements transforme une tâche utilitaire (vérifier les prix) en une expérience engageante et socialement gratifiante.

À moyen terme (6-12 mois post-lancement), envisagez des évolutions stratégiques. **Extension géographique** : Après validation à Meknès, étendez progressivement à d'autres villes marocaines (Rabat, Casablanca, Marrakech, Fès). Chaque nouvelle ville peut bénéficier de l'effet de réseau des villes précédentes. **Fonctionnalités avancées** : Ajoutez des listes de courses intelligentes avec calcul automatique du meilleur itinéraire pour minimiser les coûts, des alertes de prix personnalisées (notification quand un produit favori baisse de prix), et des statistiques de consommation pour aider les utilisateurs à budgéter. **Partenariats commerciaux** : Collaborez avec des chaînes de hanouts ou supérettes qui souhaitent promouvoir leurs prix compétitifs, créant ainsi un modèle de monétisation B2B sans compromettre l'expérience utilisateur.

L'approche Capacitor facilite également une future expansion iOS avec un investissement minimal, permettant de cibler le segment premium des utilisateurs Apple au Maroc. La même base de code React, les mêmes composants Ionic et la même logique métier fonctionneront sur iOS après quelques ajustements mineurs et tests spécifiques à la plateforme.

Hanout Price a le potentiel de devenir une infrastructure digitale essentielle pour les consommateurs marocains, démocratisant l'accès à l'information sur les prix et promouvant une économie plus transparente et équitable. La fondation technique solide établie par Capacitor et Firebase garantit que cette vision peut se concrétiser et scaler efficacement pour servir des centaines de milliers, voire des millions d'utilisateurs à travers le Maroc.
